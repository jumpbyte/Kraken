define("contents/complete", function(require, exports, module){
// @entry
require("lib/jquery");

require("lib/background").submit(null, function(){
	alert("提交完成！");
});
});

if(true){
	require("contents/complete");
}