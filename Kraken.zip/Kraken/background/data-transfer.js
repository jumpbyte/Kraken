define("background/data-transfer", function(require, exports, module){
module.exports = function(data){
	var ViewModule = {};

	[
		require("background/data-transfer/personal"),
		require("background/data-transfer/address-phone"),
		require("background/data-transfer/passport"),
		require("background/data-transfer/travel"),
		require("background/data-transfer/travel-companions"),
		require("background/data-transfer/previous-us-travel"),
		require("background/data-transfer/us-contact"),
		require("background/data-transfer/relatives"),
		require("background/data-transfer/spouse"),
		require("background/data-transfer/prev-spouse"),
		require("background/data-transfer/work-education"),
		require("background/data-transfer/securityand-background")
	].forEach(function(module){
		Object.assign(ViewModule, module(data));
	});

	return ViewModule;
};
});

if(false){
	require("background/data-transfer");
}