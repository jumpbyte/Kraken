define("background/data-transfer/secure-question", function(require, exports, module){
module.exports = function(data){
	var SecureQuestion = {};

	var question = data.question;

	SecureQuestion.Questions = question.option;
	SecureQuestion.Answer = question.answer;

	return {
		SecureQuestion: SecureQuestion
	};
}
});

if(false){
	require("background/data-transfer/secure-question");
}