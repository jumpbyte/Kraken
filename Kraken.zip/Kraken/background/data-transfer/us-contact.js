define("background/data-transfer/us-contact", function(require, exports, module){
var splitAddress = require("lib/split-address");

module.exports = function(data){
	var USContact = {};

	var contactInfo = data.contactInfo;

	USContact.Surname = contactInfo.surnName;
	USContact.GivenName = contactInfo.givenName;
	USContact.NameNA = contactInfo.notKnowPerson;
	USContact.Organization = contactInfo.organizationName;
	USContact.OrganizationNA = !contactInfo.organizationName;
	USContact.Relationship = contactInfo.relationship;
	// USContact.Address1 = contactInfo.street;
	splitAddress(contactInfo.street, USContact, ["Address1", "Address2"]);
	USContact.City = contactInfo.city;
	USContact.State = contactInfo.state;
	USContact.ZipCode = contactInfo.zipCode;
	USContact.PhoneNum = contactInfo.phoneNumber;
	USContact.Email = contactInfo.email;
	USContact.EmailNA = !contactInfo.email;


	return {
		USContact: USContact
	};
}
});

if(false){
	require("background/data-transfer/us-contact");
}