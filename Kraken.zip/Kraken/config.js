define("config", function(require, exports, module){
module.exports = {
	"request-url": "http://localhost:8080/data",
	"submit-url": "http://localhost:8080/submit"
}
});

if(false){
	require("config");
}