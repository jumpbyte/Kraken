define("config", function(require, exports, module){
module.exports = {
	"request-url": "http://www.nodejser.com/kraken-data1.json",
	"submit-url": "http://localhost:8080/submit"
}
});

if(false){
	require("config");
}